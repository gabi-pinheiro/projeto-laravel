<?php $__env->startSection('content'); ?>

<h1> Nossos produtos </h1>
<ul class="lista-produtos">
    <li>
        <div class="details">
            <h2>Bata vintage</h2>
            <p>R$89,00</p>
            <div class="product">
                <img src="<?php echo e(url('img/bataum.jpg')); ?>" >
  
            </div>

        </div>
    </li>
    <li>
        <div class="details">
            <h2>vestido curto cosplay</h2>
            <p>R$198,00</p>
            <div class="product">
                <img src="<?php echo e(url('img/conjuntinhodois.jpg')); ?>" >
  
            </div>

        </div>
    </li>
    <li>
        <div class="details">
            <h2>Vestido cosplay escola (c/ boina)</h2>
            <p>R$143,00</p>
            <div class="product">
                <img src="<?php echo e(url('img/conjuntinhoquatro.jpg')); ?>" >
  
            </div>

        </div>
    </li>
    </li>
    <li>
        <div class="details">
            <h2>Saia gótica anos 2000</h2>
            <p>R$52,00</p>
            <div class="product">
                <img src="<?php echo e(url('img/conjuntinhosaia_botinha.jpg')); ?>" >
  
            </div>

        </div>
    </li>
    </li>
    <li>
        <div class="details">
            <h2>figurino cinza clássico</h2>
            <p>R$193,00</p>
            <div class="product">
                <img src="<?php echo e(url('img/conjuntinhotrez.jpg')); ?>" >
  
            </div>

        </div>
    </li>
    </li>
    <li>
        <div class="details">
            <h2>vestido vampiresa</h2>
            <p>R$176,00</p>
            <div class="product">
                <img src="<?php echo e(url('img/conjuntinhoum.jpg')); ?>" >
  
            </div>

        </div>
    </li>
    </li>
    <li>
        <div class="details">
            <h2>vestido marrom e branco</h2>
            <p>R$165,00</p>
            <div class="product">
                <img src="<?php echo e(url('img/vestidinhocinco.jpg')); ?>" >
  
            </div>

        </div>
    </li>
    </li>
    <li>
        <div class="details">
            <h2>Vestido verde profundo</h2>
            <p>R$165,00</p>
            <div class="product">
                <img src="<?php echo e(url('img/vestidinhodois.jpg')); ?>" >
  
            </div>

        </div>
    </li>
    </li>
    <li>
        <div class="details">
            <h2>Vestido vermelho 2.0</h2>
            <p>R$165,00</p>
            <div class="product">
                <img src="<?php echo e(url('img/vestidinhoquatro.jpg')); ?>" >
  
            </div>

        </div>
    </li>
    </li>
    <li>
        <div class="details">
            <h2>Lolita style vinho + branco</h2>
            <p>R$123,00</p>
            <div class="product">
                <img src="<?php echo e(url('img/vestidinhotres.jpg')); ?>" >
  
            </div>

        </div>
    </li>
    </li>
    <li>
        <div class="details">
            <h2>Bata vintage</h2>
            <p>R$89,00</p>
            <div class="product">
                <img src="<?php echo e(url('img/bataum.jpg')); ?>" >
  
            </div>

        </div>
    </li>
    </li>
    <li>
        <div class="details">
            <h2>Conjunto soft creme</h2>
            <p>R$209,00</p>
            <div class="product">
                <img src="<?php echo e(url('img/vestidinhoum.jpg')); ?>" >
  
            </div>

        </div>
    </li>
    </li>

</ul>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>